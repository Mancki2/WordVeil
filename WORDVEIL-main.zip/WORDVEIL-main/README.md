# WORDVEIL
WordViel will have to be setup locally as publishing a extension to google play store that has permission to use user browser storage and scripting can take weeks or even months for the google store employees to review in case of malware.

If reading this from text file and not seeing images check: https://github.com/Luisbow123/WORDVEIL

HOW TO SETUP WordViel:

1. Visit chrome://extensions in Chrome (or any Chromium browser)

2. Ensure Develper mode toggle is activated:
   
![image](https://github.com/Luisbow123/WORDVEIL/assets/55300466/f340f35c-bd96-4b6b-879a-93bef54f55aa)





3.Click Load unpacked:

![image](https://github.com/Luisbow123/WORDVEIL/assets/55300466/98115757-8e5d-46a2-a8f4-5533d5e52ac6)





4. In pop-up window, select the extension folder > click Select Folder:
   
![image](https://github.com/Luisbow123/WORDVEIL/assets/55300466/3749a824-d458-4711-8453-88c3b784cf32)





5. That's it! WordViel Extension will now appear in extension list:
![image](https://github.com/Luisbow123/WORDVEIL/assets/55300466/2e35f2da-005e-4ba2-8d4c-5370293bcf84)



